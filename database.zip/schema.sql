-- Optional SQL schema for a future database-backed version.
-- The current HTML project uses browser localStorage, not SQL.

CREATE TABLE students (
    student_id VARCHAR(20) PRIMARY KEY,
    name VARCHAR(120) NOT NULL,
    course VARCHAR(20) NOT NULL,
    year INTEGER,
    barcode VARCHAR(30) UNIQUE,
    email VARCHAR(150)
);

CREATE TABLE books (
    book_number VARCHAR(20) PRIMARY KEY,
    book_name VARCHAR(200) NOT NULL,
    course VARCHAR(20) NOT NULL,
    author VARCHAR(120),
    rack VARCHAR(20),
    barcode VARCHAR(30) UNIQUE,
    status VARCHAR(20) DEFAULT 'Available',
    issue_date DATE,
    return_date DATE,
    student_name VARCHAR(120),
    student_id VARCHAR(20),
    FOREIGN KEY (student_id) REFERENCES students(student_id)
);
